#
#   tkconsole.rb - load tk/console.rb
#
require 'tk/console'
