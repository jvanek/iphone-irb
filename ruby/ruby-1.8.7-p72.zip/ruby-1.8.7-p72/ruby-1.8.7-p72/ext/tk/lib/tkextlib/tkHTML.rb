#
#  TkHtml support
#                               by Hidetoshi NAGAI (nagai@ai.kyutech.ac.jp)
#

# call setup script for general 'tkextlib' libraries
require 'tkextlib/setup.rb'

# call setup script
require 'tkextlib/tkHTML/setup.rb'

# load library
require 'tkextlib/tkHTML/htmlwidget'
